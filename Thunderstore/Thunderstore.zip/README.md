# LCZoom
Simple and customizable zoom mod for Lethal Company  

## Warning!
This mod is not compatible with FOV_Adjust and mods that changing FOV overall  
But you can use NormalFOVMultiplier setting to change default FOV  

# Changelog
### v1.0.2 - v1.0.3
* Added changelog
* Changed base zoom level from 0.2 to 0.01
### v1.0.1
* Fix for thunderstore
### v1.0.0
* Release