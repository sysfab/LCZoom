# LCZoom
Simple and customizable zoom mod for Lethal Company  

## Settings
Default keybind is `C`, you can change it in game binds menu  
I recommend to use `LethalConfig` for changing other settings  

## Warning!
This mod is not compatible with FOV_Adjust and mods that changing FOV overall  
But you can use NormalFOVMultiplier setting to change default FOV  

# Changelog
### v1.1.0
* Added support for scrolling with mouse wheel to change zoom level
* Updated README.md
### v1.0.2 - v1.0.3
* Added changelog
* Changed base zoom level from 0.2 to 0.01
### v1.0.1
* Fix for thunderstore
### v1.0.0
* Release