# LCZoom
Simple and customizable zoom mod for Lethal Company  